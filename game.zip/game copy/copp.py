import pygame
import math
import random

p1x = pygame.image.load("planex1.png")
p2x = pygame.image.load("planex2.png")
p3x = pygame.image.load("planex3.png")
p4x = pygame.image.load("planex4.png")

p1 = pygame.image.load("plane1.png")
p2 = pygame.image.load("plane2.png")
p3 = pygame.image.load("plane3.png")
p4 = pygame.image.load("plane4.png")

shield = [p1x,p2x,p3x,p4x]
none = [p1,p2,p3,p4]

class player(object):
    def __init__(self,x,y,num,angle):
        self.x = x
        self.y = y
        self.vel = 0
        self.num = num
        self.img = shield[num]
        self.i = self.img
        self.angle = angle
        self.turnspeed = 10
        self.dmg = 1
        self.hp = 10
        self.reload = 3
        self.buffer = 1
    def draw(self):
        win.blit(self.i,(self.x-(self.i.get_rect().height // 2),self.y-(self.i.get_rect().width // 2)))

def frame():
    win.fill((0,0,0))
    #win.blit(p1.i, (p1.x-(p1.i.get_rect().height // 2),p1.y-(p1.i.get_rect().width // 2)))
    for i in player:
        i.draw()
    pygame.display.update()

sw = 1300
sh = 800

p1 = player(sw//2,sh//4,1,0)
p2 = player(sw//2,sh//4 * 3,2,180)
player = [p1,p2]
pygame.init()
win = pygame.display.set_mode((sw,sh))
pygame.display.set_caption("L")

running = True
while running:
    pygame.time.delay(20)
    keys = pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type == pygame.QUIT or keys[pygame.K_ESCAPE]:
            running = False
    p1.angle += 10
    p1.i = pygame.transform.rotate(p1.img, p1.angle)
    frame()
    
pygame.quit()
    
