import pygame
import math
import random


## bug: if controlable player dies lis index overflow

p1x = pygame.image.load("planex1.png")
p2x = pygame.image.load("planex2.png")
p3x = pygame.image.load("planex3.png")
p4x = pygame.image.load("planex4.png")

p1 = pygame.image.load("plane1.png")
p2 = pygame.image.load("plane2.png")
p3 = pygame.image.load("plane3.png")
p4 = pygame.image.load("plane4.png")

u1 = pygame.image.load("laser.png")
u2 = pygame.image.load("field.png")
u3 = pygame.image.load("rocket.png")
u4 = pygame.image.load("twin.png")
u5 = pygame.image.load("jet.png")
u6 = pygame.image.load("cloak.png")

beam = pygame.image.load("beam.png")

shield = [p1x,p2x,p3x,p4x]
none = [p1,p2,p3,p4]
ups = [u1,u2,u3,u4,u5,u6]


class playr(object):
    def __init__(self,x,y,num,angle):
        self.x = x
        self.y = y
        self.vel = 10
        self.num = num
        self.img = shield[num]
        self.i = self.img
        self.angle = angle
        self.turnspeed = 10
        self.dmg = 1
        self.hp = 2
        self.reload = 3
        self.buffer = 1
        self.angle2 = 0
        self.count = 0
        self.power = -1
        self.laser = 0
    def move(self,left,right,shoot,back):
        if self.power == 1:
            self.hp += 1
            self.img = shield[self.num]
            self.power = -1
##        if self.power == 5:
##            self.reload = 6
##            self.power = -1
        if self.vel < 10:
            self.vel += 1
        elif self.vel > 10:
            self.vel -= 1
        if self.reload < 3 or self.power == 5:
            self.reload += 0.03
        if self.buffer < 1:
            self.buffer += 0.2
        if keys[left]:
            self.angle += self.turnspeed 
        if keys[right]:
            self.angle -= self.turnspeed
        if keys[back] and self.reload >= 1 and self.buffer == 1:
            self.vel += 20
            if self.vel > 40:
                self.vel = 40
            self.buffer = 0
            self.reload -= 1
            if self.power == 4:
                self.vel = 40
                for x in range(-1,2):
                    projectiles.append(projectile(self.x,self.y,self.angle + 180 + 10*x,10,4,self.num,self.dmg/4))

        if keys[shoot] and self.power == 0:
            self.laser = 5
            self.vel = -10
            self.power = -1
            self.buffer = 0
        if keys[shoot] and self.reload >= 1 and self.buffer == 1:
            self.shoot()
            self.vel = -4
            self.buffer = 0
            self.reload -= 1
        if self.x > sw:
            self.x = 0
        elif self.x < 0:
            self.x = sw
        if self.y > sh:
            self.y = 0
        elif self.y < 0:
            self.y = sh
        self.x += self.vel*math.cos(math.radians(-self.angle))
        self.y += self.vel*math.sin(math.radians(-self.angle))
                
        self.i = pygame.transform.rotate(self.img, self.angle)
    def shoot(self):
        if self.power == 3:
            projectiles.append(projectile(self.x,self.y,self.angle+15,20,5,self.num,self.dmg))
            projectiles.append(projectile(self.x,self.y,self.angle-15,20,5,self.num,self.dmg))
        if self.power == 2:
            for rot in range(18):
                projectiles.append(projectile(self.x,self.y,self.angle+(20*rot),30,5,self.num,self.dmg/2))
            self.power = -1
        else:
            projectiles.append(projectile(self.x,self.y,self.angle,20,5,self.num,self.dmg))

    def draw(self):
        if self.laser > 0:
            hyp= (sh**2 + sw**2)**0.5
            lx = self.x + (hyp*math.cos(math.radians(-self.angle)))
            ly = self.y + (hyp*math.sin(math.radians(-self.angle)))
            pygame.draw.line(win, [255,255,255], (self.x,self.y), (lx,ly),self.laser + 5)
            self.laser -= 1
        c = self.x-(self.i.get_rect().height // 2),self.y-(self.i.get_rect().width // 2)
        win.blit(self.i,c)
        r = math.floor(self.reload)
        self.angle2 += 15
        for x in range(r):
            pygame.draw.circle(win,(255,255,255),(int(self.x+50*math.cos(math.radians(-self.angle2+((360/r)*x)))),int(self.y+(50*math.sin(math.radians(-self.angle2+((360/r)*x)))))),5)

class asteroid(object):
    def __init__(self,x,y,rad):
        self.x = x
        self.y = y
        self.angle = random.randint(1,360)
        self.vel = random.randint(1,4)
        self.rad = rad
        self.hp = rad//30
        self.col = [200,150,0]
    def move(self):
        self.x += self.vel*math.cos(math.radians(-self.angle))
        self.y += self.vel*math.sin(math.radians(-self.angle))
    def die(self):
        if self.rad > 30:
            asteroids.append(asteroid(self.x,self.y,self.rad//2))
            asteroids.append(asteroid(self.x,self.y,self.rad//2))
        if random.randint(1,3) == 3:
            powers.append(power(self.x,self.y))
        asteroids.remove(self)
    def draw(self):
        pygame.draw.circle(win,self.col,(int(self.x),int(self.y)),self.rad)
    
    
class projectile(object):
    def __init__(self,x,y,angle,vel,rad,num,dmg):
        self.x = x
        self.y = y
        self.rad = rad
        self.num = num
        self.dmg = dmg
        self.x_vel = vel*math.cos(math.radians(-angle))
        self.y_vel = vel*math.sin(math.radians(-angle))
    def move(self):
        self.x += self.x_vel
        self.y += self.y_vel
    def draw(self):
        pygame.draw.circle(win,(255,255,255),(int(self.x),int(self.y)),self.rad)

def contact(a,b):
    if ((a.x-b.x)**2+(a.y-b.y)**2)**0.5 < a.rad + b.rad:
        return True
    else:
        return False

def touching(a,b):
    if a.y < b.y + ((a.i.get_rect().height + b.i.get_rect().height) // 2) and a.y > b.y - ((a.i.get_rect().height + b.i.get_rect().height) // 2) and a.x < b.x + ((a.i.get_rect().width + b.i.get_rect().width) // 2) and a.x > b.x - ((a.i.get_rect().width + b.i.get_rect().width) // 2):
        return True
    else:
        return False

class power(object):
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.type = random.randint(0,5)
        self.i = ups[self.type]
    def draw(self):
        c = self.x-(self.i.get_rect().height // 2),self.y-(self.i.get_rect().width // 2)
        win.blit(self.i,c)

def oof(i,d):
    i.hp -= d
    i.img = none[i.num]
    if i.hp <= 0 :
        player.remove(i)

def frame():
    win.fill((0,0,0))
    
    for i in player:
        i.draw()
        for a in asteroids:
            if ((i.x-a.x)**2 + (i.y-a.y)**2)**0.5 < a.rad + 5:
                if i. hp > 1:
                    oof(i,1)
                else:
                    oof(i,0.2)
                i.vel = -12
                a.die()
    for i in projectiles:
        i.move()
        i.draw()
        if i.x > sw or i.x < 0 or i.y > sh or i.y < 0:
            projectiles.remove(i)
    for p in range(len(asteroids)):
        i = asteroids[p]
        i.move()
        i.draw()
        if i.x > sw - i.rad or i.x < + i.rad:
            i.angle = 180 -  i.angle
        if i.y > sh - i.rad or i.y < + i.rad:
            i.angle = 360 -  i.angle
                 
                
    for u in powers:
        u.draw()
        for p in player:
            if touching(u,p):
                p.power = u.type
                powers.remove(u)
                break

            
            
    for p in projectiles:
        for i in player:
            if p.num != i.num and p.x < i.x + 32 and p.x > i.x - 32 and p.y < i.y + 32 and p.y > i.y - 32:
                oof(i,p.dmg)
                projectiles.remove(p)
                break
        for a in asteroids:
            #if a.x < i.x + a.rad and a.x > i.x - a.rad and a.y < i.y + a.rad and a.y > i.y - a.rad:
            if ((a.x - p.x)**2 + (a.y - p.y)**2)**0.5 < a.rad:
                a.hp -= p.dmg
                if a.hp<0:
                    a.die()
                projectiles.remove(p)
                break
    pygame.display.update()



stop = False
while stop == False:
    pygame.init()
    sw = 1400
    sh = 750
    win = pygame.display.set_mode((sw,sh))
    pygame.display.set_caption("L")

    projectiles = []
    asteroids = []
    powers = [power(sw//2,sh//2)]
    tick = 0
    
    p1 = playr(sw//2 + sw//3,sh//2 + sh//3,0,150)
    p2 = playr(sw//2 - sw//3,sh//2 + sh//3,1,30)
    p3 = playr(sw//2 + sw//3,sh//2 - sh//3,2,330)
    p4 = playr(sw//2 - sw//3,sh//2 - sh//3,3,210)
    player = [p1,p2,p3,p4]
    for ass in range(4):
        asteroids.append(asteroid(random.randint(sw//5,sw//5 * 4),random.randint(sh//5,sh//5 * 4),random.randint(20,100)))
    running = True
    while running:
        tick += 1
        pygame.time.delay(20)
        keys = pygame.key.get_pressed()
        for event in pygame.event.get():
            if event.type == pygame.QUIT or keys[pygame.K_ESCAPE]:
                stop = True
                running = False
            if keys[pygame.K_SPACE]:
                running = False
        player[0].move(pygame.K_LEFT,pygame.K_RIGHT,pygame.K_UP,pygame.K_DOWN)
        player[1].move(pygame.K_a,pygame.K_d,pygame.K_w,pygame.K_s)
        frame()
pygame.quit()


